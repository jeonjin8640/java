package exam;

public class Exam5 {
	
	public void average () {
		double avg;
	}

	public static void main(String[] args) {
		
		int[] arr = {8, 3, 1, 6, 2, 4, 5, 9};
			float sum = 0;
			double avg = 0;
			for(int i = 0; i < arr.length; i++) {
				sum += arr[i];
			}
			avg = sum/arr.length;
			
			System.out.println("평균 값 : " + avg);
	
	}
}
