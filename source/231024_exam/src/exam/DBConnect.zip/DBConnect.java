package exam;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnect {
	private static DBConnect db = new DBConnect();
	private DBConnect(){}
	public static DBConnect getInstance(){
	return db;
	}
	Connection getConnection() throws ClassNotFoundException, SQLException {
	Class.forName("com.mysql.cj.jdbc.Driver");
	String url = "jdbc:mysql://localhost:3306/kordb_member";
	String uid = "kordb";
	String pwd = "1234";
	Connection conn = DriverManager.getConnection(url, uid, pwd);
	return conn;
	}
}
