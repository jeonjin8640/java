package exam;

public class Exam3 {

	public static void main(String[] args) {
		int num = 65;
		do {
			System.out.println((char)num);
			num++;
		}while(num<91);
	}

}
