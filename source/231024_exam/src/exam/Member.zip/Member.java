package exam;

public class Member {
	private int mem_id;
	private String mem_name;
	private String mem_pwd;
	private String mem_start_regdate;
	private String mem_gender;
	private String mem_intro;
	
	public Member() {}

	public int getMem_id() {
		return mem_id;
	}

	public void setMem_id(int mem_id) {
		this.mem_id = mem_id;
	}

	public String getMem_name() {
		return mem_name;
	}

	public void setMem_name(String mem_name) {
		this.mem_name = mem_name;
	}

	public String getMem_pwd() {
		return mem_pwd;
	}

	public void setMem_pwd(String mem_pwd) {
		this.mem_pwd = mem_pwd;
	}

	public String getMem_start_regdate() {
		return mem_start_regdate;
	}

	public void setMem_start_regdate(String mem_start_regdate) {
		this.mem_start_regdate = mem_start_regdate;
	}

	public String getMem_gender() {
		return mem_gender;
	}

	public void setMem_gender(String mem_gender) {
		this.mem_gender = mem_gender;
	}

	public String getMem_intro() {
		return mem_intro;
	}

	public void setMem_intro(String mem_intro) {
		this.mem_intro = mem_intro;
	}

	@Override
	public String toString() {
		return "Member [mem_id=" + mem_id + ", mem_name=" + mem_name + ", mem_pwd=" + mem_pwd + ", mem_start_regdate="
				+ mem_start_regdate + ", mem_gender=" + mem_gender + ", mem_intro=" + mem_intro + "]";
	}
	
	
}
