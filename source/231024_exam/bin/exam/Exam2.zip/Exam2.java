package exam;

import java.util.Scanner;

public class Exam2 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		System.out.println("A(a).입력 | Q(q).종료");
		System.out.print("선택 > ");
		String str = sc.next();
		
		
		if( str.equals("a") || str.equals("A") ) {
			System.out.println("영어입력(띄어쓰기 없이) > ");
			str = sc.next();
			System.out.println(str);
		}else if( str.equals("q") || str.equals("Q") ) {
			System.out.println("프로그램 종료");
			System.exit(0);		
		}else {
			System.out.println("잘못된 메뉴입니다.");
			
	}
}
}